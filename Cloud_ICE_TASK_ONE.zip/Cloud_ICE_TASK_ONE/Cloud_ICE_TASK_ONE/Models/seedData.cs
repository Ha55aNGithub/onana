﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Cloud_ICE_TASK_ONE.Data;
using System;
using System.Linq;

namespace Cloud_ICE_TASK_ONE.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new Cloud_ICE_TASK_ONEContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<Cloud_ICE_TASK_ONEContext>>()))
        {
            // Look for any movies.
            if (context.Player.Any())
            {
                return;   // DB has been seeded
            }
            context.Player.AddRange(
                new Player
                {
                    Name = "Cristiano Ronaldo",
                    ReleaseDate = DateTime.Parse("1989-2-12"),
                    Position = "Striker",
                    Price = 7.99M
                },
                new Player
                {
                    Name = "Lionel Messi ",
                    ReleaseDate = DateTime.Parse("1984-3-13"),
                    Position = "Left Winger",
                    Price = 8.99M
                },
                new Player
                {
                    Name = "Neymar Junior",
                    ReleaseDate = DateTime.Parse("1986-2-23"),
                    Position = "Right Winger",
                    Price = 9.99M
                },
                new Player
                {
                    Name = "Bruno Fernandez",
                    ReleaseDate = DateTime.Parse("1959-4-15"),
                    Position = "Attacking Midfielder",
                    Price = 3.99M
                }
            );
            context.SaveChanges();
        }
    }
}