﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace Cloud_ICE_TASK_ONE.Controllers;

public class HelloManagerController : Controller
{

    public IActionResult Index()
    {
        return View();
    }

    public string Ready(string name, int UclWon = 1)
    {

        return
            
            HtmlEncoder.Default.Encode($"Morning {name}, " +
            $"You have {UclWon} Champion Leagues to your name");

    }
}
