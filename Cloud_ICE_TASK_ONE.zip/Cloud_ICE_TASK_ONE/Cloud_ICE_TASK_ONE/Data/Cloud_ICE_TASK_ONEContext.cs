﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Cloud_ICE_TASK_ONE.Models;

namespace Cloud_ICE_TASK_ONE.Data
{
    public class Cloud_ICE_TASK_ONEContext : DbContext
    {
        public Cloud_ICE_TASK_ONEContext (DbContextOptions<Cloud_ICE_TASK_ONEContext> options)
            : base(options)
        {
        }

        public DbSet<Cloud_ICE_TASK_ONE.Models.Player> Player { get; set; } = default!;
    }
}
